<!-- eslint-disable vue/no-multiple-template-root -->
<!--连接到主页-->
<template>
  <router-view />
</template>
