<script setup>
import CarouselMap from "./components/CarouselMap.vue";
import Recommend from "./components/Recommend.vue"
</script>

<template>
  <CarouselMap />
  <Recommend />
</template>
