<script setup>
import Head from "@/views/Login/components/head.vue";
import Login from "@/views/Login/components/Login_user.vue";
import Footer from "@/views/Login/components/footer.vue";
</script>

<template>
  <Head />
  <Login />
  <Footer />
</template>
