import goodsList from '../static/goodsList.json'
import { createStore } from 'vuex'

const state = {
  user: window.sessionStorage.getItem('user'),
  token: window.sessionStorage.getItem('token'),
  goodsList,
  is_login: false
}
const mutations = {
  SET_TOKEN: (state, data) => {
    state.token = data
    window.sessionStorage.setItem('token', data)
    state.is_login = true
  },
  GET_USER: (state, data) => {
    state.user = data
    window.sessionStorage.setItem('user', data)
  },
  LOGOUT: (state) => {
    state.token = null
    state.user = null
    window.sessionStorage.removeItem('token')
    window.sessionStorage.removeItem('user')
  }
}

const actions = {
}
export default createStore({
  state,
  mutations,
  actions
})